# FHS / SHOP — Atelier Edition

A reimagined Fishers High School spirit-shop concept with a minimal editorial aesthetic, dramatic animation, real uploaded product photography, a persistent shopping bag, and a **native WebGL 3D garment customizer**.

> **Important:** This project is an independent concept prototype, not an update to `shopfhs.com`. Prices, availability and product names are example catalog data. Order requests do not collect payment, reserve stock, send email or connect with the official shop's inventory. 3D clothing is a stylized mockup rather than a scan of the real merchandise.

## Quick start

Requires **Node.js 18+**; there is no build step and no `npm install` required.

```bash
cd FHS-Shop-Atelier
npm start
```

Open `http://localhost:3000`.

For a **static, no-server preview**, open `index.html` in a browser. Product images, theme controls, catalog filtering, shopping bag, and WebGL preview are built to work locally. AI and saving order requests need the running Node server.

## Project map

```text
FHS-Shop-Atelier/
├── index.html              # Semantic storefront markup; readable indentation
├── css/
│   └── styles.css          # Theme variables, design system, animations, responsiveness
├── js/
│   ├── catalog.js          # Bundled offline catalog of the 26 photos
│   ├── app.js              # Storefront, controls, theme, cart, order request, AI
│   └── studio3d.js         # Dependency-free WebGL 3D garment engine
├── assets/
│   └── products/           # 26 optimized original product photos (.webp)
├── data/
│   └── products.json       # Backend catalog; matches bundled catalog.js
├── server/
│   └── index.js            # HTTP backend + optional AI endpoint
├── package.json
├── .gitignore
└── README.md
```

### Catalog and shopping

- 26 supplied product photos are bundled locally. Nothing in the catalog depends on third-party image links.
- Filters: All, T-shirts, hoodies, crewnecks, and accessories. Product categories are drawn from product data.
- Instant text search and sorting by price or alphabetical name.
- Product details drawer with item image, optional size, quantity and sample price.
- Bag quantity adjustments, removal, running subtotal and persistence via `localStorage`.
- Cart and order payloads are validated by the Node backend, which recomputes prices using its own catalog.
- **No card payment** or retail checkout is implemented. The backend only writes unpaid requests to `data/orders.jsonl`.

### Native WebGL customizer

`js/studio3d.js` implements a GPU-rendered shirt with JavaScript-generated mesh triangles and shader programs. Unlike a fixed picture or an overlaid emoji, the graphics are drawn to separate front/back canvas textures and rendered onto the corresponding side of a rotating garment.

**Controls:**

1. Choose T-shirt, sweatshirt or hoodie silhouette.
2. Choose fabric from six color swatches.
3. Choose **Edit front** or **Edit back**; each has its own text, font, size, ink color, vertical position, and optional uploaded image.
4. Drag horizontally to rotate, drag vertically to tilt, scroll to zoom (or focus the canvas and use arrow keys).
5. Use Front, Back, Auto rotate or Reset view shortcuts.
6. Save the editable text/color/font settings in your browser. Uploaded artwork is not persisted for privacy and storage limitations.
7. Export a two-sided 1500×1040 PNG reference sheet with the front and back design compositions.

**Precision limitations:** The base mesh is intentionally stylized. It is not accurate to real garment sizing or stitching and does not measure print areas, decoration tolerances or copyrighted image permissions. Exports are reference previews, **not print-ready production assets**. Uploaded photos remain entirely client-side. Obtain permission to use all custom logos/marks.

### AI-assisted lettering

An optional `POST /api/ai-design` endpoint can suggest a short lettering phrase, font type and ink color. **The server requires** `OPENAI_API_KEY` as an environment variable. API keys are never embedded in browser JavaScript.

macOS/Linux example:

```bash
OPENAI_API_KEY="your-key-here" npm start
```

The AI control displays a message if the key or server is absent. All manual 3D design functionality remains available without AI.

### Theme and motion

- A persistent light/dark switch (`localStorage`) respects your system preference until manually changed.
- CSS tokens make the entire palette easy to modify in one place.
- Editorial hero, responsive product grid, animated cards, sticky header, interactive hover details, entrance transitions, fluid drawers, custom controls, and small microinteractions.
- `prefers-reduced-motion` reduces animation, and the 3D viewer suppresses auto-rotation for those users.
- Mobile-first layout adjustments, visible focus styles and keyboard shortcuts for the viewer.

## Edit the design

The CSS design tokens start at the top of `css/styles.css`:

```css
:root {
  --page: #111212;
  --ink: #f5f2ec;
  --accent: #ec4a3c;
}
html[data-theme="light"] { /* light counterparts */ }
```

To modify product titles and prices, edit **both** `data/products.json` and `js/catalog.js` (the static fallback). Prices are examples and must be replaced with approved data before official publication.

To replace product images, save a new local image in `assets/products` and update the matching record in both catalogs.

The hero currently uses `assets/products/product-05.webp`; adjust the path in `index.html` if you want another featured product.

The WebGL mesh, fabric options, lettering defaults and artwork textures are defined in `js/studio3d.js`. Main storefront behavior and control binding are in `js/app.js`.

## APIs

| Method | Route | Purpose |
|---|---|---|
| GET | `/api/health` | Health status; reports whether AI and payments are configured |
| GET | `/api/products` | Return catalog from `data/products.json` |
| POST | `/api/orders` | Validate cart and record **unpaid** order request |
| POST | `/api/ai-design` | Optional AI-generated typography suggestion |

The server intentionally **does not** publicly serve `data`, `server` or environment-secret files.

## Production launch checklist

- [ ] Secure approval to use school branding and confirm the official product catalog.
- [ ] Replace all placeholder prices, inventory and item descriptions with verified information.
- [ ] Connect real order processing and payment through an approved provider; do not collect card numbers directly.
- [ ] Add identity/authorization, inventory reconciliation, database persistence, transaction logging and rate limiting appropriate for your actual traffic.
- [ ] Decide on customer data collection/retention, privacy notice, and protection of student data.
- [ ] If desired, connect a newsletter provider. The visible form is currently only a preview; it does not subscribe users.
- [ ] Confirm shipping/pickup, refund policy, taxes and accessibility with school staff.
- [ ] Validate all garment personalization with the print vendor and licensed marks.
- [ ] Deploy the Node backend to a Node-capable service. **GitHub Pages only hosts static files** and cannot run `server/index.js` or handle orders and AI.
- [ ] Test on real desktop/mobile hardware and verify WebGL is enabled.

## Troubleshooting

**CSS looks unstyled:** Extract the full ZIP and preserve its structure. Open the top-level `index.html` or serve with `npm start`. Its stylesheet link is `./css/styles.css`, relative to the HTML file.

**Product photos missing:** Confirm `assets/products/product-01.webp` through `product-26.webp` were extracted alongside the HTML/CSS/JS directories.

**3D preview missing:** Try a current Chrome, Edge, Firefox or Safari version with hardware graphics or software WebGL support enabled. The editor shows a fallback message when WebGL is unavailable.

**AI not working:** The local HTTP server must be running and `OPENAI_API_KEY` must be provided securely on the server. Static-file preview cannot call the backend.

**Order requests not working:** Run `npm start` and confirm `/api/health` is reachable. Order requests are demo records, not paid purchases. Never use them for real fulfillment without implementing the launch checklist.

---

Built as a student shop design prototype with original supplied photographs and transparent feature limitations.
