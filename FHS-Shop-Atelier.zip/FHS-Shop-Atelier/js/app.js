/**
 * FHS SHOP — ATELIER EDITION
 * Storefront, real product photography, persistent cart, theme settings,
 * order-request backend, and 3D studio controls.
 *
 * This file is deliberately divided into small named functions.
 * No front-end framework or build process is needed.
 */
(function () {
  'use strict';

  // -------------------------------------------------------------------------
  // 01 — DOM HELPERS AND APPLICATION STATE
  // -------------------------------------------------------------------------
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));
  const PRODUCT_LIST = Array.isArray(window.FHS_PRODUCTS) ? window.FHS_PRODUCTS : [];
  const MONEY = new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD'
  });
  const STORAGE = {
    cart: 'fhs_atelier_cart_v1',
    theme: 'fhs_atelier_theme_v1',
    design: 'fhs_atelier_design_v1'
  };
  const app = {
    products: PRODUCT_LIST,
    category: 'All',
    query: '',
    sort: 'featured',
    cart: [],
    selectedProductId: null,
    drawer: null,
    viewer: null,
    editing: 'front',
    toastTimeout: null,
    lastFocus: null,
    studioTurnTimer: null
  };

  function readStorage(key, fallback) {
    try {
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : fallback;
    } catch {
      return fallback;
    }
  }

  function writeStorage(key, value) {
    try { localStorage.setItem(key, JSON.stringify(value)); } catch { /* blocked */ }
  }

  function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, (character) => ({
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      '"': '&quot;',
      "'": '&#39;'
    }[character]));
  }

  function findProduct(id) {
    return app.products.find((product) => product.id === id);
  }

  function productTitle(product) {
    return product?.name || 'Unnamed garment';
  }

  function isValidCartLine(item) {
    const product = findProduct(item?.id);
    return Boolean(product && product.sizes.includes(item.size)
      && Number.isInteger(item.quantity) && item.quantity > 0 && item.quantity <= 30);
  }

  function notify(message) {
    const toast = $('#toast');
    toast.textContent = message;
    toast.classList.add('show');
    clearTimeout(app.toastTimeout);
    app.toastTimeout = setTimeout(() => toast.classList.remove('show'), 3200);
  }

  // -------------------------------------------------------------------------
  // 02 — LIGHT/DARK MODE, SYSTEM PREFERENCE AND MOBILE MENU
  // -------------------------------------------------------------------------
  function setupTheme() {
    const saved = readStorage(STORAGE.theme, null);
    const preferred = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    applyTheme(saved === 'dark' || saved === 'light' ? saved : preferred);
    $('#themeToggle').addEventListener('click', () => {
      const current = document.documentElement.dataset.theme;
      const next = current === 'dark' ? 'light' : 'dark';
      applyTheme(next);
      writeStorage(STORAGE.theme, next);
      notify(`${next === 'dark' ? 'Dark' : 'Light'} mode activated`);
    });
  }

  function applyTheme(theme) {
    document.documentElement.dataset.theme = theme;
    $('#themeIcon').textContent = theme === 'dark' ? '☀' : '☾';
    $('#themeToggle').setAttribute('aria-label',
      theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode');
    $('meta[name="theme-color"]').content = theme === 'dark' ? '#111212' : '#f5f3ec';
  }

  function setupNavigation() {
    const mobile = $('#mobileLinks');
    $('#mobileToggle').addEventListener('click', () => {
      mobile.classList.toggle('open');
      $('#mobileToggle').setAttribute('aria-expanded',String(mobile.classList.contains('open')));
    });
    $$('a', mobile).forEach((link) => link.addEventListener('click', () => {
      mobile.classList.remove('open');
    }));
    $('#openSearch').addEventListener('click', () => {
      $('#collection').scrollIntoView({ behavior: 'smooth' });
      setTimeout(() => $('#productSearch').focus(), 500);
    });
    $('#year').textContent = new Date().getFullYear();
  }

  function setupAnimations() {
    if (!('IntersectionObserver' in window)) return;
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        entry.target.classList.add('visible');
        observer.unobserve(entry.target);
      });
    }, { threshold: .1, rootMargin: '0px 0px -25px 0px' });
    $$('.section-top, .feature, .manifesto > p, .newsletter-copy').forEach((node) => {
      node.classList.add('reveal');
      observer.observe(node);
    });
  }

  // -------------------------------------------------------------------------
  // 03 — PRODUCT FILTERS AND SORTING
  // -------------------------------------------------------------------------
  function productCategories() {
    const known = ['All', 'T-Shirts', 'Hoodies', 'Crewnecks', 'Accessories'];
    const categories = new Set(app.products.map((product) => product.category));
    return known.filter((category) => category === 'All' || categories.has(category));
  }

  function createTabs() {
    const host = $('#categoryTabs');
    host.innerHTML = '';
    productCategories().forEach((category) => {
      const button = document.createElement('button');
      button.type = 'button';
      button.textContent = category;
      button.dataset.category = category;
      button.classList.toggle('active', category === app.category);
      button.setAttribute('aria-pressed', String(category === app.category));
      button.addEventListener('click', () => {
        app.category = category;
        createTabs();
        renderProducts();
      });
      host.appendChild(button);
    });
  }

  function filteredProducts() {
    let collection = app.products.filter((product) => {
      const categoryMatches = app.category === 'All' || product.category === app.category;
      const haystack = `${product.name} ${product.category} ${product.color}`.toLowerCase();
      const textMatches = haystack.includes(app.query.toLowerCase());
      return categoryMatches && textMatches;
    });
    collection = [...collection];
    switch (app.sort) {
      case 'price-low': collection.sort((a,b) => a.price - b.price); break;
      case 'price-high': collection.sort((a,b) => b.price - a.price); break;
      case 'name': collection.sort((a,b) => a.name.localeCompare(b.name)); break;
      default: collection.sort((a,b) => Number(b.featured) - Number(a.featured));
    }
    return collection;
  }

  function makeProductCard(product, index) {
    const card = document.createElement('article');
    card.className = 'product-card';
    card.style.animationDelay = `${Math.min(index, 9) * 45}ms`;
    const label = product.featured ? 'THE TIGER EDIT' : product.customizable ? 'CUSTOM READY' : '';
    card.innerHTML = `
      <div class="product-photo" tabindex="0" role="button" aria-label="View ${escapeHtml(product.name)}">
        <img loading="lazy" src="${escapeHtml(product.image)}" alt="${escapeHtml(product.name)}" />
        ${label ? `<span class="product-label">${label}</span>` : ''}
        <button class="product-quick" type="button">VIEW DETAILS <span>↗</span></button>
      </div>
      <div class="product-meta">
        <button class="product-name" type="button">${escapeHtml(product.name)}</button>
        <span class="product-price">${MONEY.format(product.price)}</span>
      </div>
      <div class="product-subtitle">${escapeHtml(product.category)} / ${escapeHtml(product.color)}</div>
    `;
    const open = () => showProduct(product.id);
    $('.product-photo',card).addEventListener('click', (event) => {
      if (!event.target.closest('button')) open();
    });
    $('.product-photo',card).addEventListener('keydown', (event) => {
      if (event.key === 'Enter' || event.key === ' ') {
        event.preventDefault();
        open();
      }
    });
    $('.product-quick',card).addEventListener('click', open);
    $('.product-name',card).addEventListener('click', open);
    return card;
  }

  function renderProducts() {
    const collection = filteredProducts();
    const grid = $('#productGrid');
    grid.replaceChildren();
    const fragment = document.createDocumentFragment();
    collection.forEach((product,index) => fragment.appendChild(makeProductCard(product,index)));
    grid.appendChild(fragment);
    $('#emptyState').hidden = collection.length > 0;
    $('#productCount').textContent = `SHOWING ${collection.length} OF ${app.products.length} PIECES`;
  }

  function setupCollection() {
    createTabs();
    renderProducts();
    $('#productSearch').addEventListener('input', (event) => {
      app.query = event.target.value.trim();
      renderProducts();
    });
    $('#sortSelect').addEventListener('change', (event) => {
      app.sort = event.target.value;
      renderProducts();
    });
    $('#resetFilters').addEventListener('click', () => {
      app.query = '';
      app.category = 'All';
      $('#productSearch').value = '';
      $('#sortSelect').value = 'featured';
      app.sort = 'featured';
      createTabs();
      renderProducts();
    });
  }

  // -------------------------------------------------------------------------
  // 04 — ACCESSIBLE CART/DETAIL DRAWERS
  // -------------------------------------------------------------------------
  function openDrawer(id) {
    closeDrawers(false);
    app.lastFocus = document.activeElement;
    app.drawer = id;
    $('#overlay').hidden = false;
    const element = $(id);
    element.classList.add('open');
    element.setAttribute('aria-hidden','false');
    document.body.style.overflow = 'hidden';
    setTimeout(() => $('.close-btn',element)?.focus(), 60);
  }

  function closeDrawers(restoreFocus = true) {
    for (const id of ['#cartDrawer','#productDrawer']) {
      $(id).classList.remove('open');
      $(id).setAttribute('aria-hidden','true');
    }
    app.drawer = null;
    $('#overlay').hidden = true;
    document.body.style.overflow = '';
    if (restoreFocus) app.lastFocus?.focus?.();
  }

  function setupDrawers() {
    $('#openCart').addEventListener('click', () => { renderCart(); openDrawer('#cartDrawer'); });
    $('#closeCart').addEventListener('click', () => closeDrawers());
    $('#closeProduct').addEventListener('click', () => closeDrawers());
    $('#continueShopping').addEventListener('click', () => closeDrawers());
    $('#overlay').addEventListener('click', () => closeDrawers());
    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape' && app.drawer) closeDrawers();
      // Minimal keyboard focus containment for open drawers.
      if (event.key !== 'Tab' || !app.drawer) return;
      const drawer = $(app.drawer);
      const focusable = $$('button:not([disabled]), input, select, a[href]',drawer)
        .filter((element) => element.offsetParent !== null);
      if (!focusable.length) return;
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault(); last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault(); first.focus();
      }
    });
  }

  function showProduct(id) {
    const product = findProduct(id);
    if (!product) return;
    app.selectedProductId = id;
    $('#detailName').textContent = product.name;
    $('#detailImage').src = product.image;
    $('#detailImage').alt = product.name;
    $('#detailCategory').textContent = `${product.category} / ${product.color}`;
    $('#detailPrice').textContent = MONEY.format(product.price);
    $('#detailDescription').textContent = product.description;
    const sizePicker = $('#detailSize');
    sizePicker.innerHTML = '';
    product.sizes.forEach((size) => {
      const option = document.createElement('option');
      option.value = size;
      option.textContent = size;
      sizePicker.appendChild(option);
    });
    $('#detailQuantity').value = '1';
    $('#customizeProduct').hidden = !product.customizable;
    openDrawer('#productDrawer');
  }

  function getCartItemKey(item) {
    return `${item.id}::${item.size}`;
  }

  function saveCart() {
    writeStorage(STORAGE.cart, app.cart);
    updateCartBadge();
  }

  function addItem(id, size, quantity) {
    const product = findProduct(id);
    if (!product || !product.sizes.includes(size)) return;
    const q = Math.min(30,Math.max(1,Math.floor(Number(quantity) || 1)));
    const existing = app.cart.find((line) => line.id === id && line.size === size);
    if (existing) existing.quantity = Math.min(30,existing.quantity + q);
    else app.cart.push({ id, size, quantity: q });
    saveCart();
    notify(`${product.name} added to your bag`);
  }

  function removeItem(key) {
    app.cart = app.cart.filter((line) => getCartItemKey(line) !== key);
    saveCart();
    renderCart();
  }

  function changeQuantity(key, delta) {
    const item = app.cart.find((line) => getCartItemKey(line) === key);
    if (!item) return;
    const next = item.quantity + delta;
    if (next <= 0) removeItem(key);
    else {
      item.quantity = Math.min(30,next);
      saveCart();
      renderCart();
    }
  }

  function cartSubtotal() {
    return app.cart.reduce((total, item) => {
      const product = findProduct(item.id);
      return total + (product?.price || 0) * item.quantity;
    },0);
  }

  function updateCartBadge() {
    const count = app.cart.reduce((sum, item) => sum + item.quantity,0);
    $('#cartBadge').textContent = count;
    $('#drawerCount').textContent = `(${count})`;
  }

  function renderCart() {
    const host = $('#cartItems');
    host.replaceChildren();
    if (!app.cart.length) {
      host.innerHTML = '<div class="cart-empty"><div>◇</div><h3>Your bag is empty.</h3><p>The best piece is still out there.</p></div>';
    }
    app.cart.forEach((line) => {
      const product = findProduct(line.id);
      if (!product) return;
      const key = getCartItemKey(line);
      const element = document.createElement('article');
      element.className = 'cart-row';
      element.innerHTML = `
        <img src="${escapeHtml(product.image)}" alt="${escapeHtml(product.name)}" />
        <div class="cart-row-main">
          <h3>${escapeHtml(product.name)}</h3>
          <p>SIZE ${escapeHtml(line.size)} · ${escapeHtml(product.color)}</p>
          <strong>${MONEY.format(product.price * line.quantity)}</strong>
          <div class="cart-row-actions">
            <div class="qty-control"><button type="button" data-delta="-1" aria-label="Decrease quantity">−</button><span>${line.quantity}</span><button type="button" data-delta="1" aria-label="Increase quantity">+</button></div>
            <button type="button" class="remove-item">Remove</button>
          </div>
        </div>
      `;
      $$('[data-delta]',element).forEach((button) => button.addEventListener('click',
        () => changeQuantity(key,Number(button.dataset.delta))));
      $('.remove-item',element).addEventListener('click', () => removeItem(key));
      host.appendChild(element);
    });
    $('#cartSubtotal').textContent = MONEY.format(cartSubtotal());
    $('#checkoutButton').disabled = app.cart.length === 0;
  }

  function setupCart() {
    const stored = readStorage(STORAGE.cart,[]);
    app.cart = Array.isArray(stored) ? stored.filter(isValidCartLine) : [];
    updateCartBadge();
    renderCart();
    $('#addToBag').addEventListener('click', () => {
      addItem(app.selectedProductId,$('#detailSize').value,$('#detailQuantity').value);
      closeDrawers(false);
      renderCart();
      openDrawer('#cartDrawer');
    });
    $('#customizeProduct').addEventListener('click', () => {
      const product = findProduct(app.selectedProductId);
      if (product) {
        const categoryType = product.category === 'Hoodies' ? 'hoodie'
          : product.category === 'Crewnecks' ? 'crewneck' : 'tee';
        $('#garmentType').value = categoryType;
        app.viewer?.setType(categoryType);
        const colorName = String(product.color).toLowerCase();
        const color = colorName.includes('red') ? '#ba2934'
          : colorName.includes('gray') ? '#999da0'
          : colorName.includes('white') || colorName.includes('ivory') ? '#e9e4db'
          : colorName.includes('navy') ? '#1c2a43' : '#24282b';
        app.viewer?.setFabricColor(color);
        renderSwatches();
      }
      closeDrawers();
      $('#studio').scrollIntoView({ behavior: 'smooth' });
      notify('Customize a similar blank garment in 3D');
    });
  }

  // -------------------------------------------------------------------------
  // 05 — CHECKOUT AS UNPAID REQUEST, NOT A PAYMENT
  // -------------------------------------------------------------------------
  function setupOrderRequest() {
    const dialog = $('#orderDialog');
    $('#checkoutButton').addEventListener('click', () => {
      if (!app.cart.length) return;
      closeDrawers(false);
      dialog.showModal();
      $('#customerName').focus();
    });
    $('#closeOrder').addEventListener('click', () => dialog.close());
    dialog.addEventListener('click', (event) => {
      if (event.target === dialog) dialog.close();
    });
    $('#orderForm').addEventListener('submit', async (event) => {
      event.preventDefault();
      if (!app.cart.length) return;
      const status = $('#orderStatus');
      const button = $('#orderForm button[type="submit"]');
      status.textContent = 'Submitting your request…';
      button.disabled = true;
      try {
        const payload = {
          name: $('#customerName').value.trim(),
          email: $('#customerEmail').value.trim(),
          notes: $('#customerNotes').value.trim(),
          items: app.cart.map(({id,size,quantity}) => ({id,size,quantity}))
        };
        const response = await fetch('./api/orders', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });
        const result = await response.json();
        if (!response.ok) throw new Error(result.error || 'Order request was not accepted.');
        status.textContent = `Request recorded: ${result.id || result.orderId || 'success'}. No payment was taken.`;
        app.cart = [];
        saveCart();
        renderCart();
        notify('Order request recorded — no payment taken');
      } catch (error) {
        status.textContent = error instanceof TypeError
          ? 'Start the Node server with npm start to send order requests.'
          : error.message;
      } finally {
        button.disabled = false;
      }
    });
  }

  // -------------------------------------------------------------------------
  // 06 — 3D STUDIO: SYNCHRONIZING EDITING CONTROLS
  // -------------------------------------------------------------------------
  function currentArtwork() {
    return app.viewer.state[app.editing];
  }

  function updateSideButtons() {
    $('#editFront').classList.toggle('selected',app.editing === 'front');
    $('#editBack').classList.toggle('selected',app.editing === 'back');
  }

  function chooseEditingSide(side) {
    if (!app.viewer) return;
    app.editing = side;
    app.viewer.editing = side;
    app.viewer.viewSide(side);
    updateSideButtons();
    loadArtworkControls();
    updateViewButtons(side);
  }

  function updateViewButtons(side) {
    $('#frontView').classList.toggle('is-active', side === 'front' && !app.viewer.autoRotate);
    $('#backView').classList.toggle('is-active', side === 'back' && !app.viewer.autoRotate);
    $('#spinView').classList.toggle('is-active', app.viewer.autoRotate);
    $('#frontView').setAttribute('aria-pressed', String(side === 'front' && !app.viewer.autoRotate));
    $('#backView').setAttribute('aria-pressed', String(side === 'back' && !app.viewer.autoRotate));
    $('#spinView').setAttribute('aria-pressed', String(app.viewer.autoRotate));
  }

  function loadArtworkControls() {
    const art = currentArtwork();
    $('#designText').value = art.text;
    $('#textColor').value = art.ink;
    $('#fontStyle').value = art.font;
    $('#textSize').value = art.size;
    $('#textY').value = art.y;
    $('#sizeValue').textContent = `${art.size}%`;
    $('#verticalValue').textContent = `${art.y}%`;
  }

  function updateArtwork(key,value) {
    app.viewer.setSideContent(app.editing,{[key]: value});
  }

  function renderSwatches() {
    const host = $('#colorSwatches');
    host.replaceChildren();
    window.FHSFabricColors.forEach((fabric) => {
      const swatch = document.createElement('button');
      swatch.type = 'button';
      swatch.className = 'swatch';
      swatch.style.background = fabric.hex;
      swatch.title = fabric.name;
      swatch.setAttribute('aria-label',`Set fabric color to ${fabric.name}`);
      swatch.classList.toggle('active',app.viewer.state.color === fabric.hex);
      swatch.addEventListener('click', () => {
        app.viewer.setFabricColor(fabric.hex);
        renderSwatches();
      });
      host.appendChild(swatch);
    });
    const active = window.FHSFabricColors.find((entry) => entry.hex === app.viewer.state.color);
    $('#colorName').textContent = active?.name || app.viewer.state.color;
  }

  function installStudioControls() {
    $('#garmentType').addEventListener('change', (event) => {
      app.viewer.setType(event.target.value);
    });
    $('#editFront').addEventListener('click', () => chooseEditingSide('front'));
    $('#editBack').addEventListener('click', () => chooseEditingSide('back'));
    $('#frontView').addEventListener('click', () => {
      app.viewer.viewSide('front');
      updateViewButtons('front');
    });
    $('#backView').addEventListener('click', () => {
      app.viewer.viewSide('back');
      updateViewButtons('back');
    });
    $('#spinView').addEventListener('click', () => {
      app.viewer.autoRotate = !app.viewer.autoRotate;
      updateViewButtons(app.editing);
      notify(app.viewer.autoRotate ? 'Auto rotate enabled' : 'Auto rotate paused');
    });
    $('#resetView').addEventListener('click', () => {
      app.viewer.resetView();
      updateViewButtons('front');
    });
    $('#designText').addEventListener('input', (event) => {
      updateArtwork('text',event.target.value);
    });
    $('#textColor').addEventListener('input', (event) => {
      updateArtwork('ink',event.target.value);
    });
    $('#fontStyle').addEventListener('change', (event) => {
      updateArtwork('font',event.target.value);
    });
    $('#textSize').addEventListener('input', (event) => {
      const value = Number(event.target.value);
      $('#sizeValue').textContent = `${value}%`;
      updateArtwork('size',value);
    });
    $('#textY').addEventListener('input', (event) => {
      const value = Number(event.target.value);
      $('#verticalValue').textContent = `${value}%`;
      updateArtwork('y',value);
    });
    $('#artUpload').addEventListener('change', async (event) => {
      const file = event.target.files?.[0];
      if (!file) return;
      try {
        await app.viewer.uploadArtwork(app.editing,file);
        notify('Artwork added to garment');
      } catch (error) {
        notify(error.message);
      } finally {
        event.target.value = '';
      }
    });
    $('#clearArtwork').addEventListener('click', () => {
      app.viewer.removeArtwork(app.editing);
      notify('Uploaded artwork removed');
    });
    $('#downloadDesign').addEventListener('click', () => {
      app.viewer.exportDesignSheet();
      notify('Exporting front and back design sheet');
    });
    $('#saveDesign').addEventListener('click', () => {
      writeStorage(STORAGE.design,app.viewer.serialize());
      notify('Design settings saved in this browser');
    });
    $('#restoreDesign').addEventListener('click', () => {
      if (!confirm('Reset the garment and both artwork sides to defaults?')) return;
      app.viewer.resetDesign();
      chooseEditingSide('front');
      $('#garmentType').value = app.viewer.state.type;
      renderSwatches();
      notify('3D studio reset');
    });
  }

  function setup3DStudio() {
    const canvas = $('#garmentCanvas');
    try {
      app.viewer = new window.FHSGarmentViewer(canvas, {
        onMove: () => {
          $('#dragHint').classList.add('fade');
          updateViewButtons(app.editing);
        },
        onFrame: (side) => { $('#studioSideLabel').textContent = side.toUpperCase() + ' VIEW'; }
      });
      const remembered = readStorage(STORAGE.design,null);
      if (remembered) app.viewer.load(remembered);
      $('#garmentType').value = app.viewer.state.type;
      loadArtworkControls();
      renderSwatches();
      installStudioControls();
      updateSideButtons();
    } catch (error) {
      console.warn('WebGL unavailable:',error);
      $('#canvasFallback').hidden = false;
      $('#garmentCanvas').hidden = true;
      $$('.studio-panel input, .studio-panel select, .studio-panel textarea, .studio-panel button')
        .forEach((element) => { element.disabled = true; });
    }
  }

  // -------------------------------------------------------------------------
  // 07 — OPTIONAL SERVER AI DESIGN IDEAS (NO SECRET IN CLIENT)
  // -------------------------------------------------------------------------
  function setupAiDesign() {
    $('#askAi').addEventListener('click', async () => {
      const prompt = $('#aiPrompt').value.trim();
      const status = $('#aiStatus');
      if (!app.viewer) return;
      if (prompt.length < 3) {
        status.textContent = 'Describe the style you want in a few words.';
        return;
      }
      const button = $('#askAi');
      button.disabled = true;
      status.textContent = 'Thinking through a design direction…';
      try {
        const response = await fetch('./api/ai-design', {
          method: 'POST',
          headers: {'Content-Type': 'application/json'},
          body: JSON.stringify({prompt})
        });
        const data = await response.json();
        if (!response.ok) throw new Error(data.error || 'AI suggestions are unavailable.');
        const font = data.font === 'script' ? 'serif'
          : data.font === 'block' ? 'athletic' : 'modern';
        app.viewer.setSideContent(app.editing, {
          text: String(data.text || 'TIGER PRIDE').slice(0,48),
          ink: /^#[0-9a-f]{6}$/i.test(data.color) ? data.color : '#ffffff',
          font
        });
        loadArtworkControls();
        status.textContent = data.explanation || 'Suggestion applied to current garment side.';
        notify('AI lettering idea applied');
      } catch (error) {
        status.textContent = error instanceof TypeError
          ? 'AI requires npm start and an OPENAI_API_KEY on the server.'
          : error.message;
      } finally {
        button.disabled = false;
      }
    });
  }

  // -------------------------------------------------------------------------
  // 08 — OPTIONAL NEWSLETTER DEMONSTRATION
  // -------------------------------------------------------------------------
  function setupNewsletter() {
    $('#newsletterForm').addEventListener('submit', (event) => {
      event.preventDefault();
      $('#newsletterStatus').textContent =
        'Signup preview only. Connect an email platform to accept real subscriptions.';
      notify('Newsletter service not yet connected');
    });
  }

  // -------------------------------------------------------------------------
  // 09 — BOOTSTRAP THE SITE
  // -------------------------------------------------------------------------
  function initialize() {
    setupTheme();
    setupNavigation();
    setupCollection();
    setupDrawers();
    setupCart();
    setupOrderRequest();
    setup3DStudio();
    setupAiDesign();
    setupNewsletter();
    setupAnimations();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded',initialize,{once:true});
  } else {
    initialize();
  }
})();
