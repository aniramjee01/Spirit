/**
 * FHS SPIRIT SHOP — BUNDLED PRODUCT CATALOG
 * -----------------------------------------------------------
 * Local-file preview support for all 26 user-supplied photos.
 *
 * The Node.js backend reads data/products.json instead.
 * Keep this file in sync when changing product details.
 *
 * Product IDs are stable because cart entries refer to them.
 * Prices, stock, and descriptions are sample data, not verified.
 * Images are stored locally in assets/products/.
 */

window.FHS_PRODUCTS = [
    {
        "id": "fhs-01",
        "name": "Striped Tiger Overalls",
        "category": "Accessories",
        "image": "./assets/products/product-01.webp",
        "price": 42,
        "color": "Red / White",
        "sizes": [
            "XS",
            "S",
            "M",
            "L",
            "XL",
            "2XL"
        ],
        "customizable": false,
        "featured": false,
        "stock": 25,
        "description": "Official Fishers Tigers inspired spirit wear."
    },
    {
        "id": "fhs-02",
        "name": "Classic Tiger Performance Tee",
        "category": "T-Shirts",
        "image": "./assets/products/product-02.webp",
        "price": 25,
        "color": "Red",
        "sizes": [
            "XS",
            "S",
            "M",
            "L",
            "XL",
            "2XL"
        ],
        "customizable": true,
        "featured": false,
        "stock": 25,
        "description": "Official Fishers Tigers inspired spirit wear."
    },
    {
        "id": "fhs-03",
        "name": "Varsity Tigers Tee",
        "category": "T-Shirts",
        "image": "./assets/products/product-03.webp",
        "price": 22,
        "color": "Heather Gray",
        "sizes": [
            "XS",
            "S",
            "M",
            "L",
            "XL",
            "2XL"
        ],
        "customizable": true,
        "featured": false,
        "stock": 25,
        "description": "Official Fishers Tigers inspired spirit wear."
    },
    {
        "id": "fhs-04",
        "name": "Arch Fishers Crewneck",
        "category": "Crewnecks",
        "image": "./assets/products/product-04.webp",
        "price": 38,
        "color": "Ivory",
        "sizes": [
            "XS",
            "S",
            "M",
            "L",
            "XL",
            "2XL"
        ],
        "customizable": true,
        "featured": true,
        "stock": 25,
        "description": "Official Fishers Tigers inspired spirit wear."
    },
    {
        "id": "fhs-05",
        "name": "College Arch Hoodie",
        "category": "Hoodies",
        "image": "./assets/products/product-05.webp",
        "price": 45,
        "color": "Gray",
        "sizes": [
            "XS",
            "S",
            "M",
            "L",
            "XL",
            "2XL"
        ],
        "customizable": true,
        "featured": true,
        "stock": 25,
        "description": "Official Fishers Tigers inspired spirit wear."
    },
    {
        "id": "fhs-06",
        "name": "College Arch Crewneck",
        "category": "Crewnecks",
        "image": "./assets/products/product-06.webp",
        "price": 39,
        "color": "Black",
        "sizes": [
            "XS",
            "S",
            "M",
            "L",
            "XL",
            "2XL"
        ],
        "customizable": true,
        "featured": false,
        "stock": 25,
        "description": "Official Fishers Tigers inspired spirit wear."
    },
    {
        "id": "fhs-07",
        "name": "Classic Fishers Tee",
        "category": "T-Shirts",
        "image": "./assets/products/product-07.webp",
        "price": 22,
        "color": "White",
        "sizes": [
            "XS",
            "S",
            "M",
            "L",
            "XL",
            "2XL"
        ],
        "customizable": true,
        "featured": false,
        "stock": 25,
        "description": "Official Fishers Tigers inspired spirit wear."
    },
    {
        "id": "fhs-08",
        "name": "Polka Dot Fishers Crewneck",
        "category": "Crewnecks",
        "image": "./assets/products/product-08.webp",
        "price": 40,
        "color": "Ivory",
        "sizes": [
            "XS",
            "S",
            "M",
            "L",
            "XL",
            "2XL"
        ],
        "customizable": true,
        "featured": true,
        "stock": 25,
        "description": "Official Fishers Tigers inspired spirit wear."
    },
    {
        "id": "fhs-09",
        "name": "Sideline Polo",
        "category": "Polos",
        "image": "./assets/products/product-09.webp",
        "price": 38,
        "color": "Red",
        "sizes": [
            "XS",
            "S",
            "M",
            "L",
            "XL",
            "2XL"
        ],
        "customizable": true,
        "featured": false,
        "stock": 25,
        "description": "Official Fishers Tigers inspired spirit wear."
    },
    {
        "id": "fhs-10",
        "name": "School Pride Crewneck",
        "category": "Crewnecks",
        "image": "./assets/products/product-10.webp",
        "price": 39,
        "color": "Black",
        "sizes": [
            "XS",
            "S",
            "M",
            "L",
            "XL",
            "2XL"
        ],
        "customizable": true,
        "featured": false,
        "stock": 25,
        "description": "Official Fishers Tigers inspired spirit wear."
    },
    {
        "id": "fhs-11",
        "name": "Speed Logo Tee",
        "category": "T-Shirts",
        "image": "./assets/products/product-11.webp",
        "price": 24,
        "color": "Black",
        "sizes": [
            "XS",
            "S",
            "M",
            "L",
            "XL",
            "2XL"
        ],
        "customizable": true,
        "featured": true,
        "stock": 25,
        "description": "Official Fishers Tigers inspired spirit wear."
    },
    {
        "id": "fhs-12",
        "name": "Tigers Banner Crewneck",
        "category": "Crewnecks",
        "image": "./assets/products/product-12.webp",
        "price": 42,
        "color": "Red",
        "sizes": [
            "XS",
            "S",
            "M",
            "L",
            "XL",
            "2XL"
        ],
        "customizable": true,
        "featured": false,
        "stock": 25,
        "description": "Official Fishers Tigers inspired spirit wear."
    },
    {
        "id": "fhs-13",
        "name": "College Arch Hoodie · Stone",
        "category": "Hoodies",
        "image": "./assets/products/product-13.webp",
        "price": 45,
        "color": "Gray",
        "sizes": [
            "XS",
            "S",
            "M",
            "L",
            "XL",
            "2XL"
        ],
        "customizable": true,
        "featured": false,
        "stock": 25,
        "description": "Official Fishers Tigers inspired spirit wear."
    },
    {
        "id": "fhs-14",
        "name": "F Classic Baseball Cap",
        "category": "Hats",
        "image": "./assets/products/product-14.webp",
        "price": 25,
        "color": "Red",
        "sizes": [
            "One Size"
        ],
        "customizable": false,
        "featured": false,
        "stock": 25,
        "description": "Official Fishers Tigers inspired spirit wear."
    },
    {
        "id": "fhs-15",
        "name": "Tiger Mascot Tee",
        "category": "T-Shirts",
        "image": "./assets/products/product-15.webp",
        "price": 25,
        "color": "Black",
        "sizes": [
            "XS",
            "S",
            "M",
            "L",
            "XL",
            "2XL"
        ],
        "customizable": true,
        "featured": false,
        "stock": 25,
        "description": "Official Fishers Tigers inspired spirit wear."
    },
    {
        "id": "fhs-16",
        "name": "Performance Tigers Tee · Red",
        "category": "T-Shirts",
        "image": "./assets/products/product-16.webp",
        "price": 26,
        "color": "Red",
        "sizes": [
            "XS",
            "S",
            "M",
            "L",
            "XL",
            "2XL"
        ],
        "customizable": true,
        "featured": false,
        "stock": 25,
        "description": "Official Fishers Tigers inspired spirit wear."
    },
    {
        "id": "fhs-17",
        "name": "F Trucker Snapback",
        "category": "Hats",
        "image": "./assets/products/product-17.webp",
        "price": 28,
        "color": "Red / White",
        "sizes": [
            "One Size"
        ],
        "customizable": false,
        "featured": true,
        "stock": 25,
        "description": "Official Fishers Tigers inspired spirit wear."
    },
    {
        "id": "fhs-18",
        "name": "F Classic Dad Cap",
        "category": "Hats",
        "image": "./assets/products/product-18.webp",
        "price": 25,
        "color": "Red",
        "sizes": [
            "One Size"
        ],
        "customizable": false,
        "featured": false,
        "stock": 25,
        "description": "Official Fishers Tigers inspired spirit wear."
    },
    {
        "id": "fhs-19",
        "name": "Digital Camo Fishers Tee",
        "category": "T-Shirts",
        "image": "./assets/products/product-19.webp",
        "price": 28,
        "color": "Camo",
        "sizes": [
            "XS",
            "S",
            "M",
            "L",
            "XL",
            "2XL"
        ],
        "customizable": true,
        "featured": true,
        "stock": 25,
        "description": "Official Fishers Tigers inspired spirit wear."
    },
    {
        "id": "fhs-20",
        "name": "F Pom Beanie",
        "category": "Hats",
        "image": "./assets/products/product-20.webp",
        "price": 25,
        "color": "Red / Black",
        "sizes": [
            "One Size"
        ],
        "customizable": false,
        "featured": false,
        "stock": 25,
        "description": "Official Fishers Tigers inspired spirit wear."
    },
    {
        "id": "fhs-21",
        "name": "Heritage Tigers Tee",
        "category": "T-Shirts",
        "image": "./assets/products/product-21.webp",
        "price": 26,
        "color": "Black",
        "sizes": [
            "XS",
            "S",
            "M",
            "L",
            "XL",
            "2XL"
        ],
        "customizable": true,
        "featured": false,
        "stock": 25,
        "description": "Official Fishers Tigers inspired spirit wear."
    },
    {
        "id": "fhs-22",
        "name": "Vertical Logo Tee",
        "category": "T-Shirts",
        "image": "./assets/products/product-22.webp",
        "price": 24,
        "color": "Heather Gray",
        "sizes": [
            "XS",
            "S",
            "M",
            "L",
            "XL",
            "2XL"
        ],
        "customizable": true,
        "featured": false,
        "stock": 25,
        "description": "Official Fishers Tigers inspired spirit wear."
    },
    {
        "id": "fhs-23",
        "name": "Established Tigers Long Sleeve",
        "category": "Long Sleeves",
        "image": "./assets/products/product-23.webp",
        "price": 32,
        "color": "Red",
        "sizes": [
            "XS",
            "S",
            "M",
            "L",
            "XL",
            "2XL"
        ],
        "customizable": true,
        "featured": false,
        "stock": 25,
        "description": "Official Fishers Tigers inspired spirit wear."
    },
    {
        "id": "fhs-24",
        "name": "Tigers Logo Crewneck",
        "category": "Crewnecks",
        "image": "./assets/products/product-24.webp",
        "price": 40,
        "color": "White",
        "sizes": [
            "XS",
            "S",
            "M",
            "L",
            "XL",
            "2XL"
        ],
        "customizable": true,
        "featured": false,
        "stock": 25,
        "description": "Official Fishers Tigers inspired spirit wear."
    },
    {
        "id": "fhs-25",
        "name": "Vertical Logo Hoodie",
        "category": "Hoodies",
        "image": "./assets/products/product-25.webp",
        "price": 48,
        "color": "Red",
        "sizes": [
            "XS",
            "S",
            "M",
            "L",
            "XL",
            "2XL"
        ],
        "customizable": true,
        "featured": true,
        "stock": 25,
        "description": "Official Fishers Tigers inspired spirit wear."
    },
    {
        "id": "fhs-26",
        "name": "Heritage Tigers Hoodie",
        "category": "Hoodies",
        "image": "./assets/products/product-26.webp",
        "price": 48,
        "color": "Black",
        "sizes": [
            "XS",
            "S",
            "M",
            "L",
            "XL",
            "2XL"
        ],
        "customizable": true,
        "featured": true,
        "stock": 25,
        "description": "Official Fishers Tigers inspired spirit wear."
    }
];
