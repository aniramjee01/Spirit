/**
 * FHS SHOP / GARMENT ENGINE
 * ---------------------------------------------------------------------------
 * Local, dependency-free WebGL garment viewer.
 * A real GPU-rendered 3D mesh, with front/back independent canvas textures.
 *
 * Why native WebGL?
 * - The studio works without downloading Three.js from a CDN.
 * - Uploaded artwork and lettering are composed on canvases as garment decals.
 * - Mouse/touch rotation, zoom, back view and animated rotation are supported.
 * - A plain 2D design sheet is exported for production discussion.
 *
 * IMPORTANT: This is an illustrative stylized garment mesh, not a scan, a
 * manufacturing pattern, or proof of the finished printed result.
 * ---------------------------------------------------------------------------
 */
(function (global) {
  'use strict';

  const COLORS = [
    { name: 'Midnight', hex: '#24282b' },
    { name: 'Tiger red', hex: '#ba2934' },
    { name: 'Bone', hex: '#e9e4db' },
    { name: 'Stone', hex: '#999da0' },
    { name: 'Forest', hex: '#35433c' },
    { name: 'Navy', hex: '#1c2a43' }
  ];

  const INITIAL_DESIGN = () => ({
    type: 'tee',
    color: '#24282b',
    front: {
      text: 'FISHERS',
      ink: '#ffffff',
      font: 'athletic',
      size: 70,
      y: 50,
      image: null
    },
    back: {
      text: 'TIGERS',
      ink: '#ffffff',
      font: 'athletic',
      size: 65,
      y: 50,
      image: null
    }
  });

  const FONT_FAMILIES = {
    athletic: '900 58px Impact, Arial Black, sans-serif',
    modern: '900 58px Arial, Helvetica, sans-serif',
    serif: '700 58px Georgia, Times New Roman, serif',
    mono: '700 58px Courier New, monospace'
  };

  const VERTEX_SOURCE = `
    attribute vec3 aPosition;
    attribute vec2 aTexcoord;
    uniform float uAngle;
    uniform float uTilt;
    uniform float uZoom;
    varying vec2 vUV;
    varying float vLight;
    void main() {
      float c = cos(uAngle);
      float s = sin(uAngle);
      vec3 p = vec3(
        aPosition.x * c + aPosition.z * s,
        aPosition.y,
        -aPosition.x * s + aPosition.z * c
      );
      float cx = cos(uTilt);
      float sx = sin(uTilt);
      p = vec3(p.x, p.y * cx - p.z * sx, p.y * sx + p.z * cx);
      float perspective = 3.8 / (3.8 - p.z);
      gl_Position = vec4(p.x * 0.57 * perspective * uZoom,
                         p.y * 0.65 * perspective * uZoom,
                         0.0, 1.0);
      vUV = aTexcoord;
      vLight = 0.77 + 0.23 * abs(c) + 0.11 * max(0.0, sin(uTilt));
    }
  `;

  const FRAGMENT_SOURCE = `
    precision mediump float;
    uniform vec4 uColor;
    uniform sampler2D uTexture;
    uniform float uTextured;
    uniform float uShading;
    varying vec2 vUV;
    varying float vLight;
    void main() {
      vec4 base = uColor;
      if (uTextured > 0.5) {
        base = texture2D(uTexture, vUV);
      }
      gl_FragColor = vec4(base.rgb * mix(1.0, vLight, uShading), base.a);
    }
  `;

  function colorToRgb(hex) {
    const safe = /^#[0-9a-f]{6}$/i.test(hex) ? hex : '#24282b';
    return [1, 3, 5].map((i) => parseInt(safe.slice(i, i + 2), 16) / 255);
  }

  function clamp(value, min, max) {
    return Math.min(max, Math.max(min, Number(value)));
  }

  function createShader(gl, kind, source) {
    const shader = gl.createShader(kind);
    gl.shaderSource(shader, source);
    gl.compileShader(shader);
    if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
      throw new Error(gl.getShaderInfoLog(shader) || 'Shader compilation failed');
    }
    return shader;
  }

  function createProgram(gl) {
    const vertex = createShader(gl, gl.VERTEX_SHADER, VERTEX_SOURCE);
    const fragment = createShader(gl, gl.FRAGMENT_SHADER, FRAGMENT_SOURCE);
    const program = gl.createProgram();
    gl.attachShader(program, vertex);
    gl.attachShader(program, fragment);
    gl.linkProgram(program);
    gl.deleteShader(vertex);
    gl.deleteShader(fragment);
    if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
      throw new Error(gl.getProgramInfoLog(program) || 'Shader linking failed');
    }
    return program;
  }

  function safeJsonParse(value, fallback) {
    try { return JSON.parse(value); } catch { return fallback; }
  }

  function createArtworkCanvas() {
    const canvas = document.createElement('canvas');
    canvas.width = 512;
    canvas.height = 512;
    return canvas;
  }

  function drawArtwork(canvas, artwork) {
    const ctx = canvas.getContext('2d');
    const width = canvas.width;
    const height = canvas.height;
    ctx.clearRect(0, 0, width, height);

    if (artwork.image && artwork.image.complete && artwork.image.naturalWidth) {
      // Keep the uploaded image's proportions; do not stretch artwork.
      const maxWidth = 300;
      const maxHeight = 230;
      const scale = Math.min(maxWidth / artwork.image.width, maxHeight / artwork.image.height);
      const drawWidth = artwork.image.width * scale;
      const drawHeight = artwork.image.height * scale;
      ctx.drawImage(artwork.image,
                    (width - drawWidth) / 2,
                    height * clamp(artwork.y / 100, .18, .82) - drawHeight / 2,
                    drawWidth, drawHeight);
    }

    const value = String(artwork.text || '').trim().slice(0, 48);
    if (!value) return;

    const lines = value.toUpperCase().split(/\n/).slice(0, 3);
    const fontName = artwork.font || 'athletic';
    const baseFont = FONT_FAMILIES[fontName] || FONT_FAMILIES.athletic;
    const requestedSize = clamp(artwork.size || 70, 25, 100) * .8;
    ctx.fillStyle = artwork.ink || '#ffffff';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.shadowColor = 'rgba(0,0,0,.13)';
    ctx.shadowBlur = 1;
    const top = height * clamp(artwork.y / 100, .18, .82);

    lines.forEach((line, index) => {
      let size = requestedSize;
      ctx.font = baseFont.replace(/58px/, `${size}px`);
      while (size > 13 && ctx.measureText(line).width > 380) {
        size -= 2;
        ctx.font = baseFont.replace(/58px/, `${size}px`);
      }
      ctx.fillText(line, width / 2, top + (index - (lines.length - 1) / 2) * (size + 7));
    });
    ctx.shadowBlur = 0;
  }

  // Build flat-shaded triangle geometry from a 2D silhouette.
  // Each vertex holds x, y, z plus texture coordinates.
  function fanPolygon(points, depth, flip = false) {
    const data = [];
    const reference = points[0];
    const insert = (point) => {
      data.push(point[0], point[1], depth, point[0] / 3 + .5, point[1] / 3 + .5);
    };
    for (let i = 1; i < points.length - 1; i += 1) {
      if (flip) {
        insert(reference);
        insert(points[i + 1]);
        insert(points[i]);
      } else {
        insert(reference);
        insert(points[i]);
        insert(points[i + 1]);
      }
    }
    return data;
  }

  function seamBetween(points, thickness = .22) {
    const data = [];
    for (let i = 0; i < points.length; i += 1) {
      const a = points[i];
      const b = points[(i + 1) % points.length];
      const p = [[a[0], a[1], thickness / 2],
                 [b[0], b[1], thickness / 2],
                 [b[0], b[1], -thickness / 2],
                 [a[0], a[1], -thickness / 2]];
      const indices = [0, 1, 2, 0, 2, 3];
      indices.forEach((index) => {
        const v = p[index];
        data.push(v[0], v[1], v[2], 0, 0);
      });
    }
    return data;
  }

  function rectangle(x0, y0, x1, y1, z, back = false) {
    const u0 = back ? 1 : 0;
    const u1 = back ? 0 : 1;
    // UV is flipped horizontally on the rear; when rotated it reads correctly.
    return [
      x0,y0,z, u0,0,
      x1,y0,z, u1,0,
      x1,y1,z, u1,1,
      x0,y0,z, u0,0,
      x1,y1,z, u1,1,
      x0,y1,z, u0,1
    ];
  }

  class GarmentViewer {
    constructor(canvas, callbacks = {}) {
      this.canvas = canvas;
      this.callbacks = callbacks;
      this.state = INITIAL_DESIGN();
      this.editing = 'front';
      this.angle = 0;
      this.targetAngle = 0;
      this.tilt = -.09;
      this.targetTilt = -.09;
      this.zoom = .95;
      this.targetZoom = .95;
      this.autoRotate = false;
      this.dragging = false;
      this.lastX = 0;
      this.lastY = 0;
      this.userMoved = false;
      this.canvases = { front: createArtworkCanvas(), back: createArtworkCanvas() };
      this.textures = {};
      this.running = true;
      this.reducedMotion = matchMedia('(prefers-reduced-motion: reduce)').matches;
      this.frameId = null;
      this.gl = null;

      this.initializeContext();
      this.connectInput();
      this.redrawArtwork();
      this.resize();
      this.frame = this.frame.bind(this);
      this.frameId = requestAnimationFrame(this.frame);
    }

    initializeContext() {
      const gl = this.canvas.getContext('webgl', {
        alpha: true,
        antialias: true,
        premultipliedAlpha: false,
        preserveDrawingBuffer: true
      });
      if (!gl) throw new Error('This browser does not support WebGL.');
      this.gl = gl;
      this.program = createProgram(gl);
      this.attributes = {
        position: gl.getAttribLocation(this.program, 'aPosition'),
        uv: gl.getAttribLocation(this.program, 'aTexcoord')
      };
      this.uniforms = {
        angle: gl.getUniformLocation(this.program, 'uAngle'),
        tilt: gl.getUniformLocation(this.program, 'uTilt'),
        zoom: gl.getUniformLocation(this.program, 'uZoom'),
        color: gl.getUniformLocation(this.program, 'uColor'),
        texture: gl.getUniformLocation(this.program, 'uTexture'),
        textured: gl.getUniformLocation(this.program, 'uTextured'),
        shading: gl.getUniformLocation(this.program, 'uShading')
      };
      this.buffer = gl.createBuffer();
      gl.enable(gl.BLEND);
      gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
      gl.disable(gl.CULL_FACE); // Show both faces while orbiting the garment.

      for (const side of ['front', 'back']) {
        const texture = gl.createTexture();
        this.textures[side] = texture;
        gl.bindTexture(gl.TEXTURE_2D, texture);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
      }
    }

    connectInput() {
      const canvas = this.canvas;
      canvas.addEventListener('pointerdown', (event) => {
        this.dragging = true;
        this.lastX = event.clientX;
        this.lastY = event.clientY;
        canvas.setPointerCapture?.(event.pointerId);
      });
      canvas.addEventListener('pointermove', (event) => {
        if (!this.dragging) return;
        const dx = event.clientX - this.lastX;
        const dy = event.clientY - this.lastY;
        this.lastX = event.clientX;
        this.lastY = event.clientY;
        this.targetAngle += dx * .012;
        this.targetTilt = clamp(this.targetTilt + dy * .005, -.5, .5);
        this.autoRotate = false;
        this.userMoved = true;
        this.callbacks.onMove?.();
      });
      canvas.addEventListener('pointerup', () => { this.dragging = false; });
      canvas.addEventListener('pointercancel', () => { this.dragging = false; });
      canvas.addEventListener('wheel', (event) => {
        event.preventDefault();
        this.targetZoom = clamp(this.targetZoom - event.deltaY * .001, .6, 1.32);
      }, { passive: false });
      canvas.addEventListener('keydown', (event) => {
        if (event.key === 'ArrowLeft') this.targetAngle -= .18;
        if (event.key === 'ArrowRight') this.targetAngle += .18;
        if (event.key === 'ArrowUp') this.targetZoom = clamp(this.targetZoom + .08, .6, 1.32);
        if (event.key === 'ArrowDown') this.targetZoom = clamp(this.targetZoom - .08, .6, 1.32);
        if (event.key.startsWith('Arrow')) event.preventDefault();
      });
      window.addEventListener('resize', () => this.resize());
      canvas.addEventListener('webglcontextlost', (event) => {
        event.preventDefault();
        this.running = false;
      });
      canvas.addEventListener('webglcontextrestored', () => {
        this.initializeContext();
        this.redrawArtwork();
        this.running = true;
      });
    }

    resize() {
      const rect = this.canvas.getBoundingClientRect();
      const dpr = Math.min(devicePixelRatio || 1, 2);
      this.canvas.width = Math.max(1, Math.floor(rect.width * dpr));
      this.canvas.height = Math.max(1, Math.floor(rect.height * dpr));
      this.gl.viewport(0, 0, this.canvas.width, this.canvas.height);
    }

    getSilhouette() {
      const isHoodie = this.state.type === 'hoodie';
      const isCrew = this.state.type === 'crewneck';
      const torso = [[-.73,-1.2],[.73,-1.2],[.77,.73],[.54,.97],[.23,1.03],[-.23,1.03],[-.54,.97],[-.77,.73]];
      const shortSleeve = [[-.76,.73],[-.53,.97],[-1.18,.73],[-1.3,.19],[-.79,.07]];
      const longSleeve = [[-.76,.73],[-.53,.97],[-1.15,.72],[-1.34,-.84],[-.88,-.89],[-.79,.07]];
      const leftSleeve = isHoodie || isCrew ? longSleeve : shortSleeve;
      const rightSleeve = leftSleeve.map(([x,y]) => [-x,y]).reverse();
      const collar = isHoodie ? [[-.38,.99],[.38,.99],[.44,1.27],[.24,1.38],[-.24,1.38],[-.44,1.27]] : [[-.3,1.03],[.3,1.03],[.25,.9],[-.25,.9]];
      const cuffs = isHoodie || isCrew ? [
        [[-.88,-.85],[-1.34,-.8],[-1.36,-.96],[-.88,-1]],
        [[.88,-.85],[1.34,-.8],[1.36,-.96],[.88,-1]]
      ] : [];
      return { torso, leftSleeve, rightSleeve, collar, cuffs };
    }

    drawTriangles(points, rgb, options = {}) {
      const gl = this.gl;
      gl.bindBuffer(gl.ARRAY_BUFFER, this.buffer);
      gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(points), gl.STREAM_DRAW);
      gl.vertexAttribPointer(this.attributes.position, 3, gl.FLOAT, false, 20, 0);
      gl.vertexAttribPointer(this.attributes.uv, 2, gl.FLOAT, false, 20, 12);
      gl.enableVertexAttribArray(this.attributes.position);
      gl.enableVertexAttribArray(this.attributes.uv);
      gl.uniform4f(this.uniforms.color, ...rgb, 1);
      gl.uniform1f(this.uniforms.textured, options.texture ? 1 : 0);
      gl.uniform1f(this.uniforms.shading, options.shading === false ? 0 : 1);
      if (options.texture) {
        gl.activeTexture(gl.TEXTURE0);
        gl.bindTexture(gl.TEXTURE_2D, options.texture);
        gl.uniform1i(this.uniforms.texture, 0);
      }
      gl.drawArrays(gl.TRIANGLES, 0, points.length / 5);
    }

    drawMesh() {
      const gl = this.gl;
      const rgb = colorToRgb(this.state.color);
      const sideColor = rgb.map((value) => value * .69);
      const trimColor = rgb.map((value) => value * .77);
      const mesh = this.getSilhouette();
      const shapes = [mesh.torso, mesh.leftSleeve, mesh.rightSleeve];

      gl.clearColor(0, 0, 0, 0);
      gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
      gl.useProgram(this.program);
      gl.uniform1f(this.uniforms.angle, this.angle);
      gl.uniform1f(this.uniforms.tilt, this.tilt);
      gl.uniform1f(this.uniforms.zoom, this.zoom);

      // Painter's ordering: far fabric -> far decal -> seams -> near fabric
      // -> near decal. This avoids back prints bleeding through the shirt.
      const viewingBack = Math.cos(this.angle) < 0;
      const farZ = viewingBack ? .115 : -.115;
      const nearZ = viewingBack ? -.115 : .115;
      const farSide = viewingBack ? 'front' : 'back';
      const nearSide = viewingBack ? 'back' : 'front';

      shapes.forEach((shape) => {
        this.drawTriangles(fanPolygon(shape, farZ, viewingBack), sideColor);
      });
      const farDecal = farSide === 'back'
        ? rectangle(-.63,-.73,.63,.79,-.152,true)
        : rectangle(-.63,-.73,.63,.79,.152);
      this.drawTriangles(farDecal, [1,1,1], {
        texture: this.textures[farSide], shading: false
      });

      shapes.forEach((shape) => this.drawTriangles(seamBetween(shape), sideColor));
      shapes.forEach((shape) => this.drawTriangles(fanPolygon(shape, nearZ), rgb));

      for (const cuff of mesh.cuffs) {
        this.drawTriangles(fanPolygon(cuff, nearZ + (viewingBack ? -.012 : .012)), trimColor);
      }
      this.drawTriangles(fanPolygon(mesh.collar, viewingBack ? -.145 : .145), trimColor);

      if (this.state.type === 'hoodie') {
        // Stylized hood and pouch; each is intended as illustrative.
        const hood = [[-.44,1.01],[.44,1.01],[.42,1.35],[.17,1.43],[-.17,1.43],[-.42,1.35]];
        this.drawTriangles(fanPolygon(hood, viewingBack ? -.17 : .17), sideColor);
        if (!viewingBack) {
          const pouch = [[-.45,-.84],[.45,-.84],[.38,-.44],[-.38,-.44]];
          this.drawTriangles(fanPolygon(pouch, .137), trimColor);
        }
      }

      const nearDecal = nearSide === 'back'
        ? rectangle(-.63,-.73,.63,.79,-.152,true)
        : rectangle(-.63,-.73,.63,.79,.152);
      this.drawTriangles(nearDecal, [1,1,1], {
        texture: this.textures[nearSide], shading: false
      });
    }

    redrawArtwork() {
      for (const side of ['front','back']) {
        drawArtwork(this.canvases[side], this.state[side]);
        const gl = this.gl;
        gl.bindTexture(gl.TEXTURE_2D, this.textures[side]);
        gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);
        gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,this.canvases[side]);
      }
    }

    frame() {
      if (!this.running) return;
      if (this.autoRotate && !this.reducedMotion && !this.dragging) this.targetAngle += .008;
      const damping = this.reducedMotion ? 1 : .12;
      this.angle += (this.targetAngle - this.angle) * damping;
      this.tilt += (this.targetTilt - this.tilt) * damping;
      this.zoom += (this.targetZoom - this.zoom) * damping;
      this.drawMesh();
      this.callbacks.onFrame?.(Math.cos(this.angle) < 0 ? 'back' : 'front');
      this.frameId = requestAnimationFrame(this.frame);
    }

    viewSide(side) {
      this.autoRotate = false;
      const turns = Math.round(this.targetAngle / (Math.PI * 2));
      this.targetAngle = turns * Math.PI * 2 + (side === 'back' ? Math.PI : 0);
      this.targetTilt = -.09;
    }

    resetView() {
      this.autoRotate = false;
      this.targetAngle = 0;
      this.targetTilt = -.09;
      this.targetZoom = .95;
    }

    setType(type) {
      if (!['tee','hoodie','crewneck'].includes(type)) return;
      this.state.type = type;
    }

    setFabricColor(color) {
      if (!/^#[0-9a-f]{6}$/i.test(color)) return;
      this.state.color = color;
    }

    setSideContent(side, partial) {
      if (!['front','back'].includes(side)) return;
      this.state[side] = { ...this.state[side], ...partial };
      this.redrawArtwork();
    }

    async uploadArtwork(side, file) {
      if (!file || !['image/png','image/jpeg','image/webp'].includes(file.type)) {
        throw new Error('Choose a PNG, JPEG, or WebP image.');
      }
      if (file.size > 4 * 1024 * 1024) throw new Error('Artwork must be 4 MB or less.');
      const blobUrl = URL.createObjectURL(file);
      const picture = new Image();
      try {
        await new Promise((resolve, reject) => {
          picture.onload = resolve;
          picture.onerror = () => reject(new Error('Could not load that image.'));
          picture.src = blobUrl;
        });
        this.state[side].image = picture;
        this.redrawArtwork();
      } finally {
        URL.revokeObjectURL(blobUrl);
      }
    }

    removeArtwork(side) {
      this.state[side].image = null;
      this.redrawArtwork();
    }

    serialize() {
      // Images are intentionally not placed in localStorage due to size/privacy.
      const copy = JSON.parse(JSON.stringify(this.state, (key,value) => key === 'image' ? undefined : value));
      return copy;
    }

    load(saved) {
      if (!saved || typeof saved !== 'object') return;
      if (['tee','hoodie','crewneck'].includes(saved.type)) this.state.type = saved.type;
      if (/^#[0-9a-f]{6}$/i.test(saved.color)) this.state.color = saved.color;
      for (const side of ['front','back']) {
        if (!saved[side] || typeof saved[side] !== 'object') continue;
        const item = saved[side];
        this.state[side] = {
          text: String(item.text || '').slice(0,48),
          ink: /^#[0-9a-f]{6}$/i.test(item.ink) ? item.ink : '#ffffff',
          font: Object.hasOwn(FONT_FAMILIES,item.font) ? item.font : 'athletic',
          size: clamp(item.size,25,100),
          y: clamp(item.y,18,82),
          image: null
        };
      }
      this.redrawArtwork();
    }

    resetDesign() {
      this.state = INITIAL_DESIGN();
      this.editing = 'front';
      this.redrawArtwork();
      this.resetView();
    }

    drawSheetGarment(ctx, x, top, areaWidth, side) {
      const scale = areaWidth / 330;
      ctx.save();
      ctx.translate(x, top);
      ctx.scale(scale,scale);
      ctx.fillStyle = this.state.color;
      ctx.beginPath();
      const longSleeve = this.state.type !== 'tee';
      const outline = longSleeve ? [
        [-82,-112],[-43,-139],[-24,-129],[24,-129],[43,-139],
        [82,-112],[127,64],[87,73],[74,-45],[70,118],[-70,118],
        [-74,-45],[-87,73],[-127,64]
      ] : [
        [-87,-112],[-43,-139],[-24,-129],[24,-129],[43,-139],
        [87,-112],[130,-43],[99,-22],[75,-64],[70,118],[-70,118],
        [-75,-64],[-99,-22],[-130,-43]
      ];
      outline.forEach(([px,py],i) => i ? ctx.lineTo(px,py) : ctx.moveTo(px,py));
      ctx.closePath();
      ctx.fill();
      ctx.strokeStyle = 'rgba(0,0,0,.15)';
      ctx.lineWidth = 2;
      ctx.stroke();
      ctx.globalAlpha = .93;
      ctx.drawImage(this.canvases[side],-65,-101,130,167);
      ctx.globalAlpha = 1;
      ctx.restore();
    }

    exportDesignSheet() {
      const sheet = document.createElement('canvas');
      sheet.width = 1500;
      sheet.height = 1040;
      const ctx = sheet.getContext('2d');
      ctx.fillStyle = '#f1efe9';
      ctx.fillRect(0,0,sheet.width,sheet.height);
      ctx.fillStyle = '#242625';
      ctx.font = '900 58px Arial';
      ctx.fillText('FHS / DESIGN SHEET',78,110);
      ctx.font = '18px Arial';
      ctx.fillStyle = '#777';
      ctx.fillText('CONCEPT PREVIEW · NOT A PRINT-READY PRODUCTION FILE',80,150);
      ctx.fillStyle = '#d6d1c5';
      ctx.fillRect(78,192,652,650);
      ctx.fillRect(770,192,652,650);
      this.drawSheetGarment(ctx,405,515,470,'front');
      this.drawSheetGarment(ctx,1095,515,470,'back');
      ctx.fillStyle = '#252525';
      ctx.font = '800 22px Arial';
      ctx.fillText('01 / FRONT',95,235);
      ctx.fillText('02 / BACK',788,235);
      ctx.font = '18px Arial';
      ctx.fillText(`STYLE: ${this.state.type.toUpperCase()}`,80,905);
      ctx.fillText(`FABRIC: ${this.state.color.toUpperCase()}`,80,938);
      ctx.fillText(`GENERATED: ${new Date().toLocaleDateString()}`,80,971);
      ctx.fillStyle = '#888';
      ctx.font = '14px Arial';
      ctx.fillText('Confirm positioning, printable area, trademarks, and garment availability with the shop before producing.',770,931);
      const anchor = document.createElement('a');
      anchor.download = 'fhs-custom-design-sheet.png';
      anchor.href = sheet.toDataURL('image/png');
      anchor.click();
    }

    dispose() {
      this.running = false;
      cancelAnimationFrame(this.frameId);
      for (const texture of Object.values(this.textures)) this.gl.deleteTexture(texture);
      this.gl.deleteBuffer(this.buffer);
      this.gl.deleteProgram(this.program);
    }
  }

  global.FHSGarmentViewer = GarmentViewer;
  global.FHSFabricColors = COLORS;
})(window);
