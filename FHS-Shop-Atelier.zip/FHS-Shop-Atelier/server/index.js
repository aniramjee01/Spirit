/**
 * FHS SPIRIT SHOP — NODE.JS SERVER
 * ==============================================================
 *
 * Run:
 *   npm start
 *
 * Browser:
 *   http://localhost:3000
 *
 * Server responsibilities:
 *   1. Serve the storefront's HTML, CSS, JS, and images.
 *   2. Return all product records to the storefront.
 *   3. Validate and record unpaid order requests.
 *   4. Optionally request AI-generated lettering suggestions.
 *   5. Avoid accidentally exposing internal data and secrets.
 *
 * This is an educational / demonstration backend.
 * This is not a production payment processor, and order requests
 * do not reserve stock or automatically trigger fulfillment.
 *
 * Secrets are configured through environment variables, never
 * placed inside HTML, client-side JavaScript, or committed files.
 *
 * Routes:
 *   GET  /api/health       Server health and service checks
 *   GET  /api/products     Read-only product catalog
 *   POST /api/orders       Save an unpaid order request
 *   POST /api/ai-design    Generate optional typography suggestion
 *
 * Static routes:
 *   GET  /               Storefront landing page
 *   GET  /css/styles.css  Main stylesheet
 *   GET  /js/catalog.js   Bundled static product catalog
 *   GET  /js/app.js       Browser interaction logic
 *   GET  /assets/...      Shop-approved item photography
 *
 * Security overview:
 *   - Restricts files to a known public allowlist.
 *   - Prevents traversal outside the application folder.
 *   - Limits JSON request bodies and item quantities.
 *   - Does not trust browser-supplied price calculations.
 *   - Does not expose orders.jsonl publicly.
 *   - Uses no API key in client-side code.
 *   - Applies basic per-IP limits to API endpoints.
 *
 * Production deployments should add authentication,
 * a persistent database, transaction handling, anti-spam,
 * stock reservation, payment integrations, monitoring,
 * TLS, and appropriate student-data retention policies.
 */

import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

// --------------------------------------------------------------
// 01 — Application paths and runtime settings
// --------------------------------------------------------------

const serverDirectory = path.dirname(fileURLToPath(import.meta.url));
const rootDirectory = path.resolve(serverDirectory, '..');
const catalogFile = path.join(rootDirectory, 'data', 'products.json');
const orderFile = path.join(rootDirectory, 'data', 'orders.jsonl');
const port = Number(process.env.PORT) || 3000;
const maxBodyBytes = 100_000;
const maxOrderLines = 50;
const maxLineQuantity = 30;
const maxEmailLength = 160;
const maxPromptLength = 500;
const rateWindowMilliseconds = 60_000;
const maxApiRequestsPerMinute = 35;

const contentTypes = {
    '.html': 'text/html; charset=utf-8',
    '.css': 'text/css; charset=utf-8',
    '.js': 'text/javascript; charset=utf-8',
    '.json': 'application/json; charset=utf-8',
    '.webp': 'image/webp',
    '.png': 'image/png',
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.svg': 'image/svg+xml',
    '.ico': 'image/x-icon'
};

// Only these top-level assets are public.
// The /data and /server folders are deliberately not included.
const publicFolders = new Set(['css', 'js', 'assets']);
const publicFiles = new Set(['index.html']);
const apiTraffic = new Map();

// --------------------------------------------------------------
// 02 — Responses, headers, and error handling
// --------------------------------------------------------------

function sendJson(response, statusCode, body, extraHeaders = {}) {
    const json = JSON.stringify(body);
    response.writeHead(statusCode, {
        'Content-Type': 'application/json; charset=utf-8',
        'Cache-Control': 'no-store',
        'X-Content-Type-Options': 'nosniff',
        'Referrer-Policy': 'strict-origin-when-cross-origin',
        ...extraHeaders
    });
    response.end(json);
}

function sendError(response, statusCode, message) {
    sendJson(response, statusCode, { error: message });
}

function isHttpMethod(request, method) {
    return request.method === method;
}

function isValidEmail(value) {
    return typeof value === 'string'
        && value.length <= maxEmailLength
        && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
}

function isPlainObject(value) {
    return Boolean(value)
        && typeof value === 'object'
        && !Array.isArray(value);
}

function isValidHexColor(value) {
    return typeof value === 'string' && /^#[0-9a-fA-F]{6}$/.test(value);
}

function cleanString(value, maximumLength) {
    return String(value ?? '').trim().slice(0, maximumLength);
}

function safeNumber(value, fallback, min, max) {
    const parsed = Number(value);
    return Number.isFinite(parsed) ? Math.max(min, Math.min(max, parsed)) : fallback;
}

// --------------------------------------------------------------
// 03 — Read request body within a fixed size limit
// --------------------------------------------------------------

async function readJsonRequest(request) {
    const chunks = [];
    let receivedBytes = 0;

    for await (const chunk of request) {
        receivedBytes += chunk.length;
        if (receivedBytes > maxBodyBytes) {
            const error = new Error('Request body too large.');
            error.statusCode = 413;
            throw error;
        }
        chunks.push(chunk);
    }

    const text = Buffer.concat(chunks).toString('utf8');
    if (!text.trim()) {
        const error = new Error('A JSON request body is required.');
        error.statusCode = 400;
        throw error;
    }

    try {
        return JSON.parse(text);
    } catch {
        const error = new Error('Invalid JSON in request body.');
        error.statusCode = 400;
        throw error;
    }
}

// --------------------------------------------------------------
// 04 — API rate limiting (per server instance)
// --------------------------------------------------------------

function getRemoteAddress(request) {
    // Do not trust arbitrary X-Forwarded-For headers in this demo.
    return request.socket.remoteAddress || 'local';
}

function isRateLimited(request) {
    const address = getRemoteAddress(request);
    const now = Date.now();
    const previous = apiTraffic.get(address) || [];
    const recent = previous.filter((time) => now - time < rateWindowMilliseconds);
    recent.push(now);
    apiTraffic.set(address, recent);
    return recent.length > maxApiRequestsPerMinute;
}

function cleanExpiredRateLimits() {
    const now = Date.now();
    for (const [address, requests] of apiTraffic.entries()) {
        const active = requests.filter((time) => now - time < rateWindowMilliseconds);
        if (active.length) {
            apiTraffic.set(address, active);
        } else {
            apiTraffic.delete(address);
        }
    }
}

// --------------------------------------------------------------
// 05 — Product catalog operations
// --------------------------------------------------------------

async function readCatalog() {
    const contents = await fs.readFile(catalogFile, 'utf8');
    const products = JSON.parse(contents);
    if (!Array.isArray(products)) throw new Error('Product data must be an array.');
    return products;
}

async function getProducts(request, response) {
    if (!isHttpMethod(request, 'GET')) {
        return sendError(response, 405, 'Use GET for product listing.');
    }
    const products = await readCatalog();
    return sendJson(response, 200, products);
}

async function getHealth(request, response) {
    if (!isHttpMethod(request, 'GET')) {
        return sendError(response, 405, 'Use GET for health checks.');
    }
    const catalog = await readCatalog();
    sendJson(response, 200, {
        ok: true,
        application: 'FHS Shop Studio',
        mode: 'demonstration',
        products: catalog.length,
        aiConfigured: Boolean(process.env.OPENAI_API_KEY),
        paymentConfigured: false,
        timestamp: new Date().toISOString()
    });
}

// --------------------------------------------------------------
// 06 — Validating artwork submitted as part of orders
// --------------------------------------------------------------

function sanitizeDesign(value) {
    if (!isPlainObject(value)) return null;

    const font = ['bold', 'block', 'script'].includes(value.font)
        ? value.font
        : 'bold';
    const color = isValidHexColor(value.color)
        ? value.color
        : '#e32636';
    const view = value.view === 'back' ? 'back' : 'front';

    return {
        text: cleanString(value.text, 40),
        font,
        color,
        size: safeNumber(value.size, 50, 22, 110),
        x: safeNumber(value.x, 350, 155, 545),
        y: safeNumber(value.y, 342, 130, 580),
        graphic: cleanString(value.graphic, 5),
        view,
        uploadedArtworkFlag: Boolean(value.uploaded)
    };
}

function validateOrderInput(body) {
    if (!isPlainObject(body)) {
        return 'Order request must be a JSON object.';
    }
    if (!isValidEmail(body.email)) {
        return 'Please enter a valid contact email.';
    }
    if (!Array.isArray(body.items)) {
        return 'Order items must be an array.';
    }
    if (body.items.length < 1 || body.items.length > maxOrderLines) {
        return 'Order requests must contain between 1 and 50 items.';
    }
    return null;
}

function validateOrderLine(line, product) {
    if (!isPlainObject(line)) return 'Invalid cart line.';
    if (!product) return `Unknown product: ${cleanString(line.id, 32)}`;
    if (!product.sizes.includes(line.size)) return `Invalid size for ${product.name}.`;
    if (!Number.isInteger(line.quantity)) return 'Quantities must be whole numbers.';
    if (line.quantity < 1 || line.quantity > maxLineQuantity) {
        return 'Quantity must be between 1 and 30.';
    }
    return null;
}

function createOrderId() {
    const dateFragment = Date.now().toString(36).toUpperCase();
    const randomFragment = crypto.randomBytes(3).toString('hex').toUpperCase();
    return `FHS-${dateFragment}-${randomFragment}`;
}

function buildSafeOrderItems(items, catalog) {
    const safeItems = [];
    let subtotal = 0;

    for (const line of items) {
        const product = catalog.find((entry) => entry.id === line?.id);
        const problem = validateOrderLine(line, product);
        if (problem) {
            const error = new Error(problem);
            error.statusCode = 400;
            throw error;
        }

        const lineTotal = product.price * line.quantity;
        subtotal += lineTotal;
        safeItems.push({
            id: product.id,
            name: product.name,
            color: product.color,
            size: line.size,
            quantity: line.quantity,
            unitPrice: product.price,
            lineTotal,
            design: sanitizeDesign(line.design)
        });
    }

    return { safeItems, subtotal: Math.round(subtotal * 100) / 100 };
}

// --------------------------------------------------------------
// 07 — Saving requests as JSON lines (one order per line)
// --------------------------------------------------------------

async function saveOrderRequest(request, response) {
    if (!isHttpMethod(request, 'POST')) {
        return sendError(response, 405, 'Use POST to submit order requests.');
    }

    const body = await readJsonRequest(request);
    const inputProblem = validateOrderInput(body);
    if (inputProblem) return sendError(response, 400, inputProblem);

    const catalog = await readCatalog();
    const { safeItems, subtotal } = buildSafeOrderItems(body.items, catalog);

    // Prices are calculated exclusively from trusted server data.
    const order = {
        orderId: createOrderId(),
        email: body.email.trim(),
        items: safeItems,
        subtotal,
        currency: 'USD',
        status: 'REQUEST_ONLY_NOT_PAID',
        paymentCollected: false,
        stockReserved: false,
        createdAt: new Date().toISOString()
    };

    await fs.appendFile(orderFile, JSON.stringify(order) + '\n', { mode: 0o600 });

    return sendJson(response, 201, {
        orderId: order.orderId,
        message: 'Order request recorded; payment was not collected.',
        paymentCollected: false
    });
}

// --------------------------------------------------------------
// 08 — AI suggestions, sent only from the server
// --------------------------------------------------------------

function buildAiMessages(promptText) {
    return [
        {
            role: 'system',
            content: [
                'You suggest short typographic concepts for a high-school spirit shop.',
                'Respond only with valid JSON, without markdown or commentary.',
                'Use this exact shape:',
                '{"text":"up to 24 characters",',
                '"color":"#RRGGBB",',
                '"font":"bold|block|script",',
                '"explanation":"one concise sentence"}.',
                'Do not falsely claim school approval or official trademarks.'
            ].join(' ')
        },
        {
            role: 'user',
            content: promptText
        }
    ];
}

function sanitizeAiResponse(suggestion) {
    const result = isPlainObject(suggestion) ? suggestion : {};
    const font = ['bold', 'block', 'script'].includes(result.font)
        ? result.font
        : 'bold';
    const color = isValidHexColor(result.color)
        ? result.color
        : '#e32636';

    return {
        text: cleanString(result.text || 'TIGER PRIDE', 24),
        color,
        font,
        explanation: cleanString(result.explanation, 200)
    };
}

async function suggestAiDesign(request, response) {
    if (!isHttpMethod(request, 'POST')) {
        return sendError(response, 405, 'Use POST for AI suggestions.');
    }
    if (!process.env.OPENAI_API_KEY) {
        return sendError(response, 503, 'AI is not configured. Set OPENAI_API_KEY on your server.');
    }

    const body = await readJsonRequest(request);
    const promptText = typeof body?.prompt === 'string' ? body.prompt.trim() : '';
    if (promptText.length < 3 || promptText.length > maxPromptLength) {
        return sendError(response, 400, 'Prompt must contain 3–500 characters.');
    }

    const upstream = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        signal: AbortSignal.timeout(18_000),
        headers: {
            Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            model: process.env.OPENAI_MODEL || 'gpt-4o-mini',
            max_tokens: 170,
            temperature: 0.7,
            response_format: { type: 'json_object' },
            messages: buildAiMessages(promptText)
        })
    });

    if (!upstream.ok) {
        return sendError(response, 502, 'The AI provider is unavailable or the API key is invalid.');
    }

    const payload = await upstream.json();
    let parsed;
    try {
        parsed = JSON.parse(payload.choices?.[0]?.message?.content || '{}');
    } catch {
        return sendError(response, 502, 'The AI provider returned an unexpected response.');
    }

    return sendJson(response, 200, sanitizeAiResponse(parsed));
}

// --------------------------------------------------------------
// 09 — Static file serving and path safety
// --------------------------------------------------------------

function decodePublicPath(rawPathname) {
    try {
        return decodeURIComponent(rawPathname);
    } catch {
        const error = new Error('Malformed URL path.');
        error.statusCode = 400;
        throw error;
    }
}

function isAllowedPublicFile(relativePath) {
    const normalized = relativePath.replaceAll('\\', '/');
    const parts = normalized.split('/');
    if (parts.some((part) => part === '.' || part === '..' || part.startsWith('.'))) {
        return false;
    }
    if (publicFiles.has(normalized)) return true;
    return parts.length >= 2 && publicFolders.has(parts[0]);
}

function resolvePublicFile(pathname) {
    const decoded = decodePublicPath(pathname);
    const relative = decoded === '/' ? 'index.html' : decoded.replace(/^\/+/, '');

    if (!isAllowedPublicFile(relative)) {
        const error = new Error('This file is not public.');
        error.statusCode = 403;
        throw error;
    }

    const target = path.resolve(rootDirectory, relative);
    if (!target.startsWith(rootDirectory + path.sep)) {
        const error = new Error('Invalid file path.');
        error.statusCode = 403;
        throw error;
    }
    return target;
}

async function servePublicFile(request, response, pathname) {
    if (request.method !== 'GET' && request.method !== 'HEAD') {
        return sendError(response, 405, 'Only GET and HEAD are supported for files.');
    }

    const target = resolvePublicFile(pathname);
    const extension = path.extname(target).toLowerCase();
    const mimeType = contentTypes[extension] || 'application/octet-stream';
    const bytes = await fs.readFile(target);

    response.writeHead(200, {
        'Content-Type': mimeType,
        'X-Content-Type-Options': 'nosniff',
        'Referrer-Policy': 'strict-origin-when-cross-origin',
        'Cache-Control': extension === '.html' ? 'no-cache' : 'public, max-age=3600'
    });

    response.end(request.method === 'HEAD' ? undefined : bytes);
}

// --------------------------------------------------------------
// 10 — Main routing and consistent error responses
// --------------------------------------------------------------

async function routeApi(request, response, pathname) {
    if (isRateLimited(request)) {
        return sendError(response, 429, 'Too many requests. Please try again later.');
    }

    switch (pathname) {
        case '/api/health':
            return getHealth(request, response);
        case '/api/products':
            return getProducts(request, response);
        case '/api/orders':
            return saveOrderRequest(request, response);
        case '/api/ai-design':
            return suggestAiDesign(request, response);
        default:
            return sendError(response, 404, 'Unknown API endpoint.');
    }
}

async function handleRequest(request, response) {
    try {
        const url = new URL(request.url, 'http://localhost');
        const pathname = url.pathname;
        if (pathname.startsWith('/api/')) {
            return await routeApi(request, response, pathname);
        }
        return await servePublicFile(request, response, pathname);
    } catch (error) {
        if (error.code === 'ENOENT') {
            return sendError(response, 404, 'File not found.');
        }
        if (error.statusCode) {
            return sendError(response, error.statusCode, error.message);
        }
        if (error.name === 'TimeoutError') {
            return sendError(response, 504, 'The AI request timed out.');
        }
        console.error('[FHS server]', error);
        return sendError(response, 500, 'Unexpected server error.');
    }
}

// --------------------------------------------------------------
// 11 — Start the server and configure graceful shutdown
// --------------------------------------------------------------

const server = http.createServer(handleRequest);

server.listen(port, () => {
    console.log('');
    console.log('=================================================');
    console.log(' FHS SPIRIT SHOP · LOCAL DEVELOPMENT SERVER');
    console.log('=================================================');
    console.log(` Open website:    http://localhost:${port}`);
    console.log(` Health endpoint: http://localhost:${port}/api/health`);
    console.log(` AI configured:   ${Boolean(process.env.OPENAI_API_KEY)}`);
    console.log(' Order handling:  Requests only; payments disabled');
    console.log('=================================================');
    console.log('');
});

function shutdown(signal) {
    console.log(`Received ${signal}; stopping the server.`);
    server.close(() => process.exit(0));
}

process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));

// This cleanup is intentionally invoked on incoming requests instead
// of using an always-on timer; no external process manager is needed.
server.on('request', () => {
    if (apiTraffic.size > 200) cleanExpiredRateLimits();
});
